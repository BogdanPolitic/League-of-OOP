package gameplay;

public class Damage {
	public int damage;

	public Damage(int damage) {
		this.damage = damage;
	}
}
