package gameplay;

public class OvertimeAndHPdrop {
	public Overtime overtime;
	public int HPdrop;
	
	public OvertimeAndHPdrop(Overtime overtime, int HPdrop) {
		this.overtime = overtime;
		this.HPdrop = HPdrop;
	}
	
}
