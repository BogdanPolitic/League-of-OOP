package gameplay;

public class HP {
	public int BasicHP;
	public int CurrentHP;
	
	public HP(int basicHP, int currentHP) {
		BasicHP = basicHP;
		CurrentHP = currentHP;
	}
	
}
