package main;

public class FightLocation {
	int rand, col;

	public FightLocation ( int rand, int col ) {
		this.rand = rand;
		this.col = col;
	}
	
}
