package main;

public class IniPos {
	char rasa;
	int rand;
	int col;
	
	public IniPos (char rasa, int rand, int col) {
		this.rasa = rasa;
		this.rand = rand;
		this.col = col;
	}
}
